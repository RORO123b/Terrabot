package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Entity {
    protected String name;
    protected double mass;
    protected String type;
}
