package entities.air;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class TemperateAir extends Air {
    private static final double HUMIDITY_FACTOR = 0.7;
    private static final double POLLEN_FACTOR = 0.1;
    private static final double OXYGEN_FACTOR = 2;
    private static final double MAX_SCORE_VALUE = 84;
    private static final double SPRING_PENALTY = 15;

    private double pollenLevel;
    private String season;

    public TemperateAir(final String type, final String name, final double mass,
                        final double humidity, final double temperature,
                        final double oxygenLevel, final double pollenLevel) {
        this.type = type;
        this.name = name;
        this.mass = mass;
        this.humidity = humidity;
        this.temperature = temperature;
        this.oxygenLevel = oxygenLevel;
        this.pollenLevel = pollenLevel;
        season = "";
        setAirQuality();
        calculateToxicityAQ();
    }

    public final int getMaxScore() {
        return (int) MAX_SCORE_VALUE;
    }

    /**
     * Sets the air quality for temperate air.
     */
    public void setAirQuality() {
        airQuality = (oxygenLevel * OXYGEN_FACTOR) + (humidity * HUMIDITY_FACTOR)
                - (pollenLevel * POLLEN_FACTOR);
        airQuality = Math.max(0, Math.min(MAX_QUALITY, airQuality));
        airQuality -= (season.equalsIgnoreCase("Spring") ? SPRING_PENALTY : 0);
        airQuality = Math.max(0, Math.min(MAX_QUALITY, airQuality));
    }

    /**
     * Changes weather by setting the season.
     * @param season The season name
     */
    @Override
    public void changeWeather(final String newSeason) {
        this.season = newSeason;
        setAirQuality();
    }
}
